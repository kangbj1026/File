const mysql = require("mysql2/promise");
const 
{
	MYSQL_HOST,
	MYSQL_USER,
	MYSQL_PWD,
	MYSQL_DB
} = process.env;

module.exports = mysql.createPool(
	{
		host : MYSQL_HOST,
		user : MYSQL_USER,
		password : MYSQL_PWD,
		database : MYSQL_DB,
		connectTimeout : 5000,
		connectionLimit : 30
	}
)

// const connection = mysql.createConnection(
// {
// 	host	: "localhost",
// 	user	: "root",
// 	password: "rabbit87!@",
// 	database: "my_db"
// });

// connection.connect();

// connection.query("select * from member",(error,rows,fields) =>
// {
// 	if (error) throw error;

// 	console.log("member info is: ", rows);
// });

// connection.end();