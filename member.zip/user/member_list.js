const express = require("express");
const { patch } = require("../home");
const router = express.Router();

// const getConnection = require('../db');
// getConnection((conn) => {
// 		conn.query("select * from members",(error,rows,fields)=>
// 		{
// 			if (error) throw error;

// 			console.log("aaaaaaaaaaaaaaaaaaaaaa");

// 			router.route("/")
// 			.get((req,res)=>
// 			{
// 				res.send(rows);
// 			})
// 		});	conn.release();
// });

router.route("/")
.get((req,res)=>
{
	const getConnection = require('../db');
	getConnection((conn) => 
	{
		conn.query("select * from members",(error,rows,fields)=>
		{
			if (error) throw error;
			
			res.sendFile(__dirname + "/member_list.html");
			// res.send(rows);
		});	conn.release();
	});
})
// router.get('/',

// (req, res, next) => 
// {
// 	console.log('실행됩니다.');
//     next("route"); // 다음 라우터 미들웨어로 점프한다.
// 	res.send('Hello, Express Router ');
// }, 

// (req, res, next) => 
// {
//     console.log('실행되지 않습니다.');
//     next();
// });

module.exports = router;