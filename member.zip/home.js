const express = require("express");
const router = express.Router();

router.get('/',

(req, res, next) => 
{
	console.log('실행됩니다.');
    next("route"); // 다음 라우터 미들웨어로 점프한다.
	res.send('Hello, Express Router ');
}, 

(req, res, next) => 
{
    console.log('실행되지 않습니다.');
    next();
});

router.route("/admin")
.get((req,res)=>
{
	res.send("관리자 모드");
})
.post((req,res)=>
{
	res.send("POST /admin");
});

module.exports = router;