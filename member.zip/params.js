const express = require("express");
const router = express.Router();

router.get("/",(req,res)=>
{
	res.sendFile(__dirname + '/html/params.html');
});
router.get("/key/:id",(req,res)=>
{
	console.log(req.params);
	console.log(req.query);

	const json = JSON.stringify(req.query);
	/**
	* JavaScript 값을 JSON(JavaScript Object Notation) 문자열로 변환합니다.
	* @param value 변환할 자바스크립트 값으로, 일반적으로 객체 또는 배열입니다.
	* @param replacer 문자열화할 개체 속성을 선택하기 위해 승인된 목록 역할을 하는 문자열 및 숫자의 배열입니다.
	* @param space 반환 값 JSON 텍스트에 들여쓰기, 공백 및 줄 바꿈 문자를 추가하여 읽기 쉽게 합니다.
	*/

	res.send(`req.params = ${req.params.id} , req.query = ${json}`);
});
module.exports = router;