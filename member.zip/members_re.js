const e = require("express");
const express = require("express");
const router = express.Router();
const getConnection = require('../db');

// 회원 목록
router.route("/")
.get((req,res)=>
{
	res.sendFile(__dirname + "/html/member.html");
});

router.route("/Join")
.get((req,res)=>
{
	res.sendFile(__dirname + "/html/Join.html");
});

// 회원가입
router.route("/join")
.post((req,res)=>
{
	const name = ReParams(req.body.name);
	const sql = query(req.baseUrl.replace(/[\/]/g,"") , name.replace(/[\"]/g,"'") , req.url.replace(/[\/]/g,""));

	if (name != "" && name.length != 0)
	{
		getConnection((conn) => 
		{
			conn.query(sql,(error,rows,fields)=>
			{
				if (error)
				{
					throw error;
				}
				else
				{
					if (Object.keys(rows).length != 0)
					{
						res.send("이미 존재하는 회원입니다.");
						end(conn);
					}
					else
					{
						Insert(conn,req,res);
					}
				}
			});
		});
	}
	else
	{
		res.send("회원의 이름을 입력하지 않았습니다.");
	}

});

// 회원 목록
router.route("/list")
.get((req,res)=>
{
	const sql = query(req.baseUrl.replace(/[\/]/g,""),undefined,req.url.replace(/[\/]/g,""));

	getConnection((conn) => 
	{
		conn.query(sql,(error,rows,fields)=>
		{
			if (error) throw error;
			
			// res.sendFile(__dirname + "/member_list.html");
			res.send(rows);
		});	conn.release();
	});
});

// 회원 삭제
router.route("/delete/:id")
.delete((req,res)=>
{
	const id = ReParams(req.params.id);
	const sql = query(req.baseUrl.replace(/[\/]/g,""),id.replace(/[\/]/g,""),req.method);

	getConnection((conn) => 
	{
		conn.query(sql,(error,rows,fields)=>
		{
			if (error) throw error;
	
			if (rows.affectedRows == 1) {
				res.send(id+"회원님의 계정이 삭제 되었습니다.");
			}
			else 
			{
				res.send(id+"회원님은 존재하지 않는 회원입니다.");
			}

		});	conn.release();
	});
});

// 회원 수정
router.route("/update/:id")
.put((req,res)=>
{
	const id = ReParams(req.params.id);
	const sql = query(req.baseUrl.replace(/[\/]/g,""),id.replace(/[\/]/g,""),req.method);

	getConnection((conn) => 
	{
		conn.query(sql,(error,rows,fields)=>
		{
			if (error) throw error;
	
			if (Object.keys(rows).length != 0) {
				update(id,res,req);
			}
			else 
			{
				res.send(id+"회원님은 존재하지 않는 회원입니다.");
			}

		});	conn.release();
	});
});



/**
	@param {conn Databse 접근 요청 } conn
	@param {request 클라이언트로부터 서버에 받게 되는 코드 , 응답 } req
	@param {response 서버가 클라이언트에게 보내주는 코드 , 요청 } res
*/
function Insert(conn,req,res)
{
	const name = ReParams(req.body.name);
	const check = inputCheck(req);

	if (check != undefined)
	{
		res.send(`${check}를 입력하지 않았습니다.`);
	}
	else
	{
		const sql = query(req.baseUrl.replace(/[\/]/g,""),req.body,"INSERT");

		conn.query(sql,(error,rows,fields)=>
		{
			if (error) throw error;
	
			console.log("insert Success!!!!!");
			const result = "insert Success! " + rows.insertId + "번의 " + name + "님의 회원가입을 축하합니다.";
			res.send(result);
	
		});	conn.release();
	}
};

function inputCheck(req)
{
	const age = ReParams(req.body.age);
	const department = ReParams(req.body.department);
	const position = ReParams(req.body.position);
	const work = ReParams(req.body.work);
	const phone = ReParams(req.body.phone);

	const undefinedArray = [];
	let undefinedCount = 0;
	let undefinedText = "";

	if(age == "" && age.length == 0)
	{
		undefinedCount += 1;
		undefinedArray.push("age(나이)");
	}

	if(department == "" && department.length == 0)
	{
		undefinedCount += 1;
		undefinedArray.push("department(부서)");
	}
	
	if(position == "" && position.length == 0)
	{
		undefinedCount += 1;
		undefinedArray.push("position(직위)");
	}
	
	if(work == "" && work.length == 0)
	{
		undefinedCount += 1;
		undefinedArray.push("work(해당 업무)");
	}
	
	if(phone == "" && phone.length == 0)
	{
		undefinedCount += 1;
		undefinedArray.push("phone(핸드폰 번호)");
	}

	for(let i = 0; undefinedCount > i; i++)
	{
		if (i == 0)
		{
			undefinedText += undefinedArray[i];
		}
		else 
		{
			undefinedText += "," + undefinedArray[i];
		}
	}

	if(undefinedArray != "")
	{
		return undefinedText;
	}
}

function update(id,res,req)
{
	const body = req.body;
	const check = inputCheck(req);

	if (check != undefined)
	{
		res.send(`수정 할 부분에 ${check}에 아무런 값도 입력되지 않았습니다. 그리하여 수정 할 수 없습니다.`);
	}
	else
	{
		const sql = query(req.baseUrl.replace(/[\/]/g,""),req,"UPDATE");
		getConnection((conn) => 
		{
			conn.query(sql,(error,rows,fields)=>
			{
				if (error) throw error;
		
				res.send(id+"님의 정보가 수정 완료되었습니다.");
		
			});	conn.release();
		});
	}

	// const age = ReParams(body.age);
	// const department = ReParams(body.department);
	// const position = ReParams(body.position);
	// const work = ReParams(body.work);
	// const phone = ReParams(body.phone);
	// const undefinedArray = [];
	// let undefinedCount = 0;
	// let undefinedText = "";

	// if (age == "" || age.length == 0)
	// {
	// 	undefinedCount += 1;
	// 	undefinedArray.push("age(나이)");
	// }
	
	// if (department == "" || department.length == 0)
	// {
	// 	undefinedCount += 1;
	// 	undefinedArray.push("department(부서)");
	// }
	
	// if (position == "" || position.length == 0)
	// {
	// 	undefinedCount += 1;
	// 	undefinedArray.push("position(직위)");
	// }
	
	// if (work == "" || work.length == 0)
	// {
	// 	undefinedCount += 1;
	// 	undefinedArray.push("work(해당 업무)");
	// }
	
	// if (phone == "" || phone.length == 0)
	// {
	// 	undefinedCount += 1;
	// 	undefinedArray.push("phone(핸드폰 번호)");
	// }
	
	// for(let i = 0; undefinedCount > i; i++)
	// {
	// 	if (i == 0)
	// 	{
	// 		undefinedText += undefinedArray[i];
	// 	}
	// 	else 
	// 	{
	// 		undefinedText += ","+undefinedArray[i];
	// 	}
	// }

	// if (undefinedArray == "")
	// {
	// 	const sql = query(req.baseUrl.replace(/[\/]/g,""),req,"UPDATE");
	// 	getConnection((conn) => 
	// 	{
	// 		conn.query(sql,(error,rows,fields)=>
	// 		{
	// 			if (error) throw error;
		
	// 			res.send(id+"님의 정보가 수정 완료되었습니다.");
		
	// 		});	conn.release();
	// 	});
	// }
	// else
	// {
	// 	res.send(`수정 할 부분에 ${undefinedText}에 아무런 값도 입력되지 않았습니다. 그리하여 수정 할 수 없습니다.`);
	// }
}

function query(table,values,url)
{
	let sql_find = `select * from `;
	let sql_insert = `${url} into ${table}s (name,age,department,position,work,phone) `;
	let sql_update = `${url} ${table}s set `;
	let sql_delete = `${url} from `;
	let sql_where_name = `where name = `;

	let last_sql = "";
	if(url == "list")
	{
		sql_find += `${table}s`;
		last_sql = sql_find;
	}
	else if (url == "join" || url == "PUT")
	{
		sql_find += `${table}s ${sql_where_name} "${values}"`;
		last_sql = sql_find;
	}
	else if (url == "INSERT")
	{
		sql_insert += `values(
			"${ReParams(values.name)}",
			"${ReParams(values.age)}",
			"${ReParams(values.department)}",
			"${ReParams(values.position)}",
			"${ReParams(values.work)}",
			"${ReParams(values.phone)}")`;

		last_sql = sql_insert;
	}
	else if (url == "UPDATE")
	{
		sql_update += `
			age = "${ReParams(values.body.age)}",
			department = "${ReParams(values.body.department)}",
			position = "${ReParams(values.body.position)}",
			work = "${ReParams(values.body.work)}",
			phone = "${ReParams(values.body.phone)}" 
			${sql_where_name} "${values.params.id}"`;

		last_sql = sql_update;
	}
	else if (url == "DELETE")
	{
		sql_delete += `${table}s ${sql_where_name} "${values}"`;
		last_sql = sql_delete;
	}
	else
	{

	}

	const result = last_sql;
	return result;
}

function ReParams(params)
{
	const param = `${params}`;
	const reParam = param.replace(/\s*/g,"");
	return reParam;
}

function end(conn)
{
	conn.end();
};

function error(res)
{
	res.send("잘못된 경로입니다.");
}

module.exports = router;