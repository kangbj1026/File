const express = require("express");
const app = express();
const dotenv = require("dotenv");

const indexRouter = require("./home");
const htmlRouter = require("./html");
const params = require("./params");
const memberRouter = require("./user/members");

dotenv.config();

app.use(express.json()); // json만 구문 분석하고 Content-Type 헤더가 유형 옵션과 일치하는 요청만 보는 미들웨어를 반환합니다.
app.use(express.urlencoded({extended:false})); // URL 인코딩된 본문만 구문 분석하고 Content-Type 헤더가 유형 옵션과 일치하는 요청만 확인하는 미들웨어를 반환합니다
  
app.set('port', process.env.PORT);

app.use("/params",params); // 모든 요청에 미들웨어를 실행하며, app.http메서드() 는 각 요청에서 미들웨어가 실행
app.use("/html",htmlRouter);
app.use("/member",memberRouter);
app.use("/",indexRouter);

// process.on('uncaughtException',function (err)
// {
	// const main = "<h1><a href='/'> Main </a></h1>";
	//	throw new Error()를 써서 에러를 강제로 발생
	//	throw를 하는 경우 반드시 try/catch 문으로 throw한 에러를 잡아야한다.
	// console.log(new Error('server error!'));
	// app.send(`잘못된 접근입니다. 메인으로 돌아가주세요. ${main}`);

	// console.log("uncaugthExeption :\n", err);

	// if (err.code == "ECONNREFUSED" || err.code == "EHOSTUNREACH")
	// {
	// 	handler_connetct_error (err);
	// }
	// else if(err.code == "ETIMEDOUT")
	// {
	// 	andler_timeout(err);
	// }
// });

// process.on('uncaughtException',function (err)
// {
// 	try
// 	{
// 		// const main = "<h1><a href='/'> Main </a></h1>";
// 		// throw new Error()를 써서 에러를 강제로 발생
// 		// throw를 하는 경우 반드시 try/catch 문으로 throw한 에러를 잡아야한다.
// 		// console.log(new Error('server error!'));
// 		res.send(`잘못된 접근입니다. 메인으로 돌아가주세요. ${main}`);

// 		// console.log("uncaugthExeption :\n", err);

// 		if (err.code == "ECONNREFUSED" || err.code == "EHOSTUNREACH")
// 		{
// 			handler_connetct_error (err);
// 		}
// 		else if(err.code == "ETIMEDOUT")
// 		{
// 			andler_timeout(err);
// 		}

// 	}
// 	catch (err) 
// 	{
// 		console.log("uncaugthExeption :\n", err);

// 		if (err.code == "ECONNREFUSED" || err.code == "EHOSTUNREACH")
// 		{
// 			handler_connetct_error (err);
// 		}
// 		else if(err.code == "ETIMEDOUT")
// 		{
// 			andler_timeout(err);
// 		}
// 	}
// });

// 서버를 실행
app.listen(app.get("port"),()=>
{
	console.log(app.get("port"),"번 포트에서 대기 중....");
});