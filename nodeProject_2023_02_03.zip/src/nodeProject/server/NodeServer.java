package nodeProject.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import org.json.JSONObject;

import nodeProject.data.Member;

public class NodeServer 
{
	public static String LocalhostURL = "http://localhost:3000";
	public static HashMap<Long, Member> hashMapParams = new HashMap<>();
	public static ArrayList<Member> arrayListParams = new ArrayList<Member>();
	Scanner scanner = new Scanner(System.in);
	
	public NodeServer()
	{
		while (true) 
		{
			showMenu();
			
			int memberNo = arrayListParams.size();
			
			String menuNumS = NextLine(scanner);
			int menuNum = 0;

			if (menuNumS.equals(""))
			{
				System.out.println("잘못 입력하였습니다.");
				continue;
			}
			else if (menuNumS.chars().allMatch(Character::isDigit) == true)
			{
				menuNum = Integer.parseInt(menuNumS);
			}
			
			if (menuNum == 2 || menuNum == 3 || menuNum == 4)
			{
				Boolean result = checkSize(arrayListParams);
				if (result == false)
				{
					continue;	
				}
			}
			
			if (menuNum == 1)
			{
				System.out.println("생성할 회원 클래스의 Name를 입력해주세요. <숫자,문자,특수문자( \" 제외[가입시 제거되서 입력됨]),한글 가능> ");
				
				// 사원 생성
				Member member = new Member();
						
				// 사원 정보 설정
				boolean check = true;
				String name = scanner.nextLine();
				for (int i = 0; i < memberNo; i++) 
				{
					Member m = arrayListParams.get(i);
					if (m.getName().equals(name)) 
					{
						System.out.println(name+"님은 이미 존재하는 회원입니다.");
						check = false;
					}
				}

				if (check == false)
				{
					continue;
				}

				System.out.print("Age : ");
				Integer age = scanner.nextInt();
				scanner.nextLine();
				System.out.print("Department : ");
				String department = scanner.nextLine();
				System.out.print("Position : ");
				String position = scanner.nextLine();
				System.out.print("Work : ");
				String work = scanner.nextLine();
				System.out.print("Phone : ");
				String phone = scanner.nextLine();
				
//				paramsToString = null;
//				hashMapParams.forEach((k,v) ->
//				{
//					Member m = hashMapParams.get(k);
//					paramsToString = "id="+m.getId()+"&name="+m.getName()+"&age="+m.getAge()+"&department="+m.getDepartment()+"&position="+m.getPosition()+"&work="+m.getWork()+"&phone="+m.getPhone();
//					paramsToString = "name="+m.getName()+"&age="+m.getAge()+"&department="+m.getDepartment()+"&position="+m.getPosition()+"&work="+m.getWork()+"&phone="+m.getPhone();
//					paramsToString = "name="+name+"&age="+age+"&department="+department+"&position="+position+"&work="+work+"&phone="+phone;
//				});

				ArrayList<String> paramValue = new ArrayList<>();
				paramValue.add(name);
				paramValue.add(String.valueOf(age));
				paramValue.add(department);
				paramValue.add(position);
				paramValue.add(work);
				paramValue.add(phone);
				
				paramsConnectionJoin(member, paramValue);
				
//				paramsToString = "name="+name+"&age="+age+"&department="+department+"&position="+position+"&work="+work+"&phone="+phone;
//				
//				HttpURLConnection connection = Connection(LocalhostURL,param,"POST","join");
//
//				String params = DataString(connection);

//				System.out.println(params);
//				System.out.println(params.equals(""));
//				System.out.println(params.getBytes());
//				System.out.println("부서를 입력하지 않았습니다.".getBytes());
//				System.out.println(params.contains(params));
				
//				if (params.equals(""))
//				if (params.contains("이미") == true)
//				{
//					System.out.println(params);
//				}
//				else if (params.contains("입력하지 않았습니다.") == true) // 문자를 포함하고 있는지 확인 여부
//				{
//					System.out.println(params);
//				}
//				else
//				{
//					Long id = Long.valueOf(params.substring(params.indexOf("!")+2,params.indexOf("번")));
//					// 사원 목록에 저장
//					memberSave(member, id, name, age, department, position, work, phone);
//					System.out.println(params);
//				}
			}
			else if (menuNum == 2)
			{
				HttpURLConnection connection = Connection(LocalhostURL,null,"GET","list");
				String params = DataString(connection);
				
				memberFineList(arrayListParams, hashMapParams);
				System.out.println(params);
			}
			else if (menuNum == 3)
			{
				System.out.println("검색할 회원 Name 를 입력해주세요.");
				String memberName = scanner.nextLine();
				
				for (int i = 0; i < memberNo; i++) 
				{
					Member m = arrayListParams.get(i);
					if (m.getName().equals(memberName)) 
					{
						if (m.getId() != null)
						{
							System.out.println("1. 읽기");
							System.out.println("2. 수정");
							System.out.println("3. 삭제");
							System.out.println("4. 취소");
							
							int sequence = scanner.nextInt();
							scanner.nextLine();
							
							if (sequence == 1)
							{
								System.out.println("member Id         : " + m.getId());
								System.out.println("member Name       : " + m.getName());
								System.out.println("member Age        : " + m.getAge());
								System.out.println("member Department : " + m.getDepartment());
								System.out.println("member Position   : " + m.getPosition());
								System.out.println("member Work       : " + m.getWork());
								System.out.println("member Phone      : " + m.getPhone()+"\n");
								continue;
							}
							else if (sequence == 2)
							{
								System.out.print("Age : ");
								Integer age = scanner.nextInt();
								scanner.nextLine();
								System.out.print("department : ");
								String department = scanner.nextLine();
								System.out.print("position : ");
								String position = scanner.nextLine();
								System.out.print("work : ");
								String work = scanner.nextLine();
								System.out.print("Phone : ");
								String phone = scanner.nextLine();
								
								System.out.println("수정하시겠습니까? ");
								checkNum();
								int upDate = scanner.nextInt();
								scanner.nextLine();
								if (upDate == 1)
								{
									String updateString = "age="+age+"&department="+department+"&position="+position+"&work="+work+"&phone="+phone;
									
									HttpURLConnection connection = Connection(LocalhostURL,updateString,"PUT","update/"+memberName);
									
									String params = DataString(connection);
									
									m.setAge(age);
									m.setDepartment(department);
									m.setPosition(position);
									m.setWork(work);
									m.setPhone(phone);

									System.out.println(params);
								}
								else
								{
									System.out.println("취소 되었습니다.");
									continue;							
								}
								
								System.out.println(memberName + "회원님의 클래스가 수정되었습니다.");
								continue;
							}
							else if (sequence == 3)
							{
								System.out.println("정말 삭제하시겠습니까?");
								checkNum();
								int delete = scanner.nextInt();
								scanner.nextLine();
								int minus = 0;
								
								for (int y = 0; y < memberNo; y++)
								{
									if (arrayListParams.get(y).getId() == m.getId())
									{
										minus = y;
									}
								}
								
								if (delete == 1)
								{
									HttpURLConnection connection = Connection(LocalhostURL,null,"DELETE","delete/"+m.getName());
									
									String param = DataString(connection);
									
									System.out.println(param);
									
									arrayListParams.remove(minus);
									hashMapParams.remove(m.getId());
									System.out.println(memberName+ "회원님의 클래스가 삭제되었습니다.");
									break;	
								}
								else if (delete == 2)
								{
									System.out.println("취소 되었습니다.");
									continue;							
								}
								else 
								{
									System.out.println("잘못 입력하였습니다.");
									continue;								
								}
							}
							else if (sequence == 4)
							{
								System.out.println("취소 하였습니다.");
								continue;
							}
							else
							{
								System.out.println("잘못 입력하였습니다.");
								continue;							
							}
						}
						else
						{
							
							System.out.println("회원 ID 가 맞지 않습니다.");
							continue;
						}
					}
					else
					{
						System.out.println("존재하지 않는 회원입니다.");
						continue;
					}
				}
			}
			else if (menuNum == 4)
			{
				System.out.println("현재 저장된 모든 회원 저장 할 수 있습니다.");
				System.out.println("저장할 파일명을 입력해주세요.");
				String fileName = scanner.nextLine();
				
				File file;
				try
				{
					file = new File("src/info/"+fileName+".txt");
				}
				catch (Exception e) 
				{
					System.out.println("잘못 입력하였습니다.\n");
					continue;
				}
				
				if (file.exists())
				{
					System.out.println("동일한 파일이 존재합니다. 진행하시겠습니까? ");
					checkNum();
					int check = scanner.nextInt();
					scanner.nextLine();
					if (check == 1)
					{
					}
					else
					{
						System.out.println("취소 되었습니다.");
						continue;							
					}
				}
				
				FileWriter writerList = null;
				FileWriter writerMap = null;
				
				try
				{
					writerList = new FileWriter("src/info/"+fileName+".txt");
					writerMap = new FileWriter("src/info/"+fileName+".json");
				} 
				catch (Exception e) 
				{
					System.out.println(e + ", 파일 생성에 실패하였습니다.");
					continue;
				}
				
				try
				{
					for(int i = 0; i < arrayListParams.size(); i++)
					{
						Member m = arrayListParams.get(i);						
						writerList.write(m.getId() + "\n");
						writerList.write(m.getName()+ "\n");
						writerList.write(m.getAge() + "\n" );
						writerList.write(m.getDepartment()+ "\n");
						writerList.write(m.getPosition()+ "\n");
						writerList.write(m.getWork()+ "\n");
						writerList.write(m.getPhone()+ "\n");
					}
					
					System.out.println("저장이 완료 되었습니다.");
					writerList.flush();
					writerList.close();
					
					JSONObject jsonData = new JSONObject(hashMapParams);
					
					writerMap.write(jsonData.toString());
					writerMap.flush();
					writerMap.close();
				}
				catch (IOException e) 
				{
					System.out.println("저장에 실패하였습니다.");
				}
			}
			else if (menuNum == 5)
			{
				System.out.println("\n검색할 파일명을 입력해주세요.");
				String fileName = scanner.nextLine();
				File file = new File("src/info/"+fileName+".txt");
				if(file.exists() == false) 
				{
					System.out.print("파일이 존재 하지 않습니다.\n");
				}
				else
				{
					System.out.println("현재 저장된 회원 클래스와 Database에 모두 제거 하고 진행하시겠습니까?");
					checkNum();
					System.out.println("3. 현재 저장된 회원 클래스와 Database에 저장된 회원들을 제거 하지 않고 붙혀넣기");
					int checkOne = scanner.nextInt();
					scanner.nextLine();
					
					if (checkOne == 1)
					{
						System.out.println("신중하게 선택해주세요. 정말 모두 초기화 하시겠습니까?");
						checkNum();
						int checkTwo = scanner.nextInt();
						scanner.nextLine();
						
						if (checkTwo == 1)
						{	
							HttpURLConnection connection = Connection(LocalhostURL,null,"DELETE","delete/passwordEncryption"); // 아주 위험한 부분
							
							String param = DataString(connection);
							
							System.out.println(param);
							
							arrayListParams.clear();
							hashMapParams.clear();
							
							try
							{
							    BufferedReader inFile = new BufferedReader(new FileReader(file));
							    
							    String line = null;
							    
							    while ((line = inFile.readLine()) != null)
				            	{
				            		Member member = new Member();
				            	
				            		String memberId = line;
				            		String memberName = inFile.readLine();
				            		String memberAge = inFile.readLine();
				            		String memberDepartment = inFile.readLine();
				            		String memberPosition = inFile.readLine();
				            		String memberWork = inFile.readLine();
				            		String memberPhone = inFile.readLine();

				    				ArrayList<String> paramValue = new ArrayList<>();
				    				paramValue.add(memberName);
				    				paramValue.add(memberAge);
				    				paramValue.add(memberDepartment);
				    				paramValue.add(memberPosition);
				    				paramValue.add(memberWork);
				    				paramValue.add(memberPhone);
				    				
				    				paramsConnectionJoin(member, paramValue);
				    				
				            	}
							    inFile.close();
							    
							    System.out.println("불러오기가 완료되어 사원 클래스와 Database에 저장 되었습니다.");
							}
							catch (IOException e) 
							{
								System.out.println("파일 읽기에 실패하였습니다.");
								continue;
							}
						}
						else 
						{
							System.out.println("취소 되었습니다.");
							continue;		
						}
					}
					else if (checkOne == 3) 
					{
						try
						{
						    BufferedReader inFile = new BufferedReader(new FileReader(file));
						    
						    String line = null;
						    
						    while ((line = inFile.readLine()) != null)
			            	{
			            		Member member = new Member();
			            	
			            		String memberId = line;
			            		String memberName = inFile.readLine();
			            		String memberAge = inFile.readLine();
			            		String memberDepartment = inFile.readLine();
			            		String memberPosition = inFile.readLine();
			            		String memberWork = inFile.readLine();
			            		String memberPhone = inFile.readLine();

			    				ArrayList<String> paramValue = new ArrayList<>();
			    				paramValue.add(memberName);
			    				paramValue.add(memberAge);
			    				paramValue.add(memberDepartment);
			    				paramValue.add(memberPosition);
			    				paramValue.add(memberWork);
			    				paramValue.add(memberPhone);
			    				
			    				paramsConnectionJoin(member, paramValue);
			    				
			            	}
						    inFile.close();
						    
						    System.out.println("붙혀넣기가 완료되어 사원 클래스와 Database 저장 되었습니다.");
						}
						catch (IOException e) 
						{
							System.out.println("파일 읽기에 실패하였습니다.");
							continue;
						}
					}
					else 
					{
						System.out.println("취소 되었습니다.");
						continue;							
					}
				}
			}
			else if (menuNum == 6)
			{
				System.out.println("프로그램을 종료합니다.");
				break;
			}
			else
			{
				System.out.println("잘못 입력하였습니다.");
				continue;
			}
		}
	}
	
	public String NextLine(Scanner sc)
	{
		String input = sc.nextLine();
		return input;
	}
	public int NextInt(Scanner sc)
	{
		int input = sc.nextInt();
		sc.nextLine();
		return input;
	}
	
	public void memberSave(Member member, Long id, String name, int age, String department, String position, String work, String phone) {
    	member.setId(id);
    	member.setName(name);
    	member.setAge(age);
    	member.setDepartment(department);
    	member.setPosition(position);
    	member.setWork(work);
    	member.setPhone(phone);
    	
    	arrayListParams.add(member);
        hashMapParams.put(id, member);
	}
	
	private static void showMenu()
	{
		System.out.println("========== 메뉴 목록 ==========");
		System.out.println("1. 회원 클래스 생성 ");
		System.out.println("2. 회원 클래스 리스트 ");
		System.out.println("3. 회원 클래스 검색 ");
		System.out.println("4. 회원 클래스 데이터 저장 ( ArrayList.txt, HashMap.json ) ");
		System.out.println("5. 저장된 txt file 불러오기 ");
		System.out.println("6. 프로그램 종료 ");
		System.out.println("=============================");
		System.out.print("원하시는 업무를 선택해주세요 : ");
	}
	
	private static boolean checkSize(ArrayList<Member> list)
	{
		if (list.size() == 0)
		{
			System.out.println("사원 클래스가 존재하지 않습니다.");
			return false;
		}
		else
		{
			return true;
		}
	}
	
	private static void memberFineList(ArrayList<Member> list, HashMap<Long, Member> map) {
		System.out.println("---------- ArrayList -----------");
		for(int i = 0; i < list.size(); i++)
		{
			Member mL = list.get(i);
			System.out.println("member Id         : " + mL.getId());
			System.out.println("member Name       : " + mL.getName());
			System.out.println("member Age        : " + mL.getAge());
			System.out.println("member Department : " + mL.getDepartment());
			System.out.println("member Position   : " + mL.getPosition());
			System.out.println("member Work       : " + mL.getWork());
			System.out.println("member Phone      : " + mL.getWork()+"\n");
		}
		System.out.println("--------------------------------");
		System.out.println("---------- HashMap -----------");
		map.forEach((key,value) -> {
			String result = "";
			
			result 
			+= key + " : \n{ "
				+ "	'Id' 		: '" + value.getId() + "' , \n"
				+ "	'name'		: '"+ value.getName() + "' , \n"
				+ "	'age' 		: '" + value.getAge() + "' , \n"
				+ "	'department'	: '" + value.getDepartment() + "' , \n"
				+ "	'position' 	: '" + value.getPosition() + "' , \n"
				+ "	'work' 		: '" + value.getWork() + "', \n} "
				+ "	'phone' 		: '" + value.getPhone() + "' \n} ";
			System.out.println(result);
		});
		System.out.println("--------------------------------");
	}
	
	public void paramsConnectionJoin(Member m,ArrayList<String> params)
	{
		ArrayList<String> paramKey = new ArrayList<>();
		
		paramKey.add("name");
		paramKey.add("age");
		paramKey.add("department");
		paramKey.add("position");
		paramKey.add("work");
		paramKey.add("phone");
		
		String param = "";
		for (int i = 0; params.size() > i;i++) 
		{
			param += paramKey.get(i) +"="+ params.get(i)+"&";	
		}
		
		param = param.substring(0, param.length() - 1);
		
		HttpURLConnection connection = Connection(LocalhostURL,param,"POST","join");

		param = DataString(connection);
		
		if (param.contains("이미") == true)
		{
			System.out.println(param);
		}
		else if (param.contains("입력하지 않았습니다.") == true) // 문자를 포함하고 있는지 확인 여부
		{
			System.out.println(param);
		}
		else
		{
			Long id = Long.valueOf(param.substring(param.indexOf(""),param.indexOf("번")));
			
			// 사원 목록에 저장
			memberSave(m, id, params.get(0), Integer.parseInt(params.get(1)), params.get(2), params.get(3), params.get(4), params.get(5));
			System.out.println(param);
		}
	}
	
	public String DataString(HttpURLConnection connection)
	{
		try 
		{
			InputStream is = connection.getInputStream();
			// 요청결과 (response)를 BufferedReader로 받습니다.
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));

			// 자바 5 이상은 StringBuffer 를 이용해서 결과 값을 읽습니다.
			StringBuilder response = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) 
			{
				response.append(line);
				response.append('\r');
			}
			rd.close();
			return response.toString();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public HttpURLConnection Connection(String targetURL,String params, String method, String path)
	{
		HttpURLConnection connection = null;
		DataOutputStream wr = null;

		try 
		{
			URL url = null;
			String contentType = null;
			if (method == "POST")
			{
				contentType = "application/x-www-form-urlencoded";
				if(path == "join")
				{
					url = URL(targetURL+"/member/"+path);	
				}
				else 
				{
					url = URL(targetURL);
				}
			}
			else if (method == "GET")
			{
				contentType = "application/json";
				if(path == "list")
				{
					url = URL(targetURL+"/member/"+path);	
				}
				else 
				{
					url = URL(targetURL);
				}
			}
			else if (method == "PUT")
			{
				contentType = "application/x-www-form-urlencoded";
				url = URL(targetURL+"/member/"+path);
			}
			else if (method == "DELETE")
			{
				contentType = "text/html";
				url = URL(targetURL+"/member/"+path);
			}
			else
			{
				System.out.println("잘못 접근하였습니다.");
			}
			
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod(method);
			connection.setRequestProperty("Content-Type", contentType);
			
			connection.setUseCaches(false);
			connection.setDoOutput(true);
			
			if(params != null)
			{
				wr = new DataOutputStream(connection.getOutputStream());				
				wr.write(params.getBytes("UTF-8"));
				wr.close();				
			}
			
			return connection;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public URL URL(String url)
	{
		URL targetUrl;
		try 
		{
			targetUrl = new URL(url);
			return targetUrl;
		} 
		catch (MalformedURLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	private static void checkNum() {
		System.out.println("1. 확인");
		System.out.println("2. 취소");
	}
	
	public void exit()
	{
		System.exit(0);		
	}
	
	public static void main(String[] args) 
	{
		new NodeServer();
	}
}
