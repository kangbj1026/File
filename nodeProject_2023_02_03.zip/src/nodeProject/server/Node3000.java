package nodeProject.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Node3000 
{

	public Node3000()
	{
		HttpURLConnection connection = httpURLConnection("http://localhost:3000","about");
		System.out.println(connection);
		String params = DataString(connection);
		
		System.out.println(params);
	}
	
	public String DataString(HttpURLConnection connection)
	{
		try 
		{
			InputStream is = connection.getInputStream();
			// 요청결과 (response)를 BufferedReader로 받습니다.
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			// 자바 5 이상은 StringBuffer 를 이용해서 결과 값을 읽습니다.
			StringBuilder response = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) 
			{
				response.append(line);
				response.append('\r');
			}
			rd.close();
			return response.toString();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public HttpURLConnection httpURLConnection(String targetUrl, String params)
	{
		HttpURLConnection connection = null;
		DataOutputStream wr = null;
		
		try 
		{
			URL url = new URL(targetUrl);
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Content-Type", "text/html");
			
			connection.setUseCaches(false);
			connection.setDoOutput(true);
			
			wr = new DataOutputStream(connection.getOutputStream());
			
			wr.write(params.getBytes("UTF-8"));
			wr.close();	
			
			return connection;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
		
	}
	public static void main(String[] args) 
	{
		new Node3000();
	}
}
