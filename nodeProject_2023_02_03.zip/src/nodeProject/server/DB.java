package nodeProject.server;

public class DB 
{
	public static DB Instance = null;
	
	public static DB getConnection()
	{
		if (Instance == null)
		{
			Instance = new DB();
		}
		return Instance;
	}	
}