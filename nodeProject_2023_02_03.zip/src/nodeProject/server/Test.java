package nodeProject.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Test 
{

	public static void main(String[] args) 
	{
		HttpURLConnection connection = null;
		DataOutputStream wr = null;
		
		try 
		{
			String targetURL = "http://localhost:3000";
			URL url = null;
			String contentType = null;
			String method = null;

			String params = "";
			url = new URL(targetURL);
			method = "GET";
			contentType = "application/json; utf-8";
			
			connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod(method);
			connection.setRequestProperty("Content-Type", contentType);
			connection.setRequestProperty("Accept", contentType);
			
			connection.setUseCaches(false);
			connection.setDoOutput(true);
//			connection.connect();
//			System.out.println(connection.getInputStream());
//			wr = new DataOutputStream(connection.getOutputStream());
			
//			wr.write(params.getBytes("UTF-8"));
//			wr.close();	
			System.out.println(wr);
			System.out.println(connection);
			
			try 
			{
//				InputStream is = connection.getInputStream();
				// 요청결과 (response)를 BufferedReader로 받습니다.
				BufferedReader rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));

				// 자바 5 이상은 StringBuffer 를 이용해서 결과 값을 읽습니다.
				StringBuilder response = new StringBuilder();
				String line;
				while ((line = rd.readLine()) != null) 
				{
					response.append(line);
					response.append('\r');
				}
				rd.close();
				
				System.out.println(response.toString());
				
//				return response.toString();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
//				return null;
			}
			
//			return connection;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
//			return null;
		}
	}
}